#BasicVision
=============

This is a very basic OpenCV sample for use in SUNY Polytechnic Institute's Computer Vision course.  It only relies on OpenCV.
